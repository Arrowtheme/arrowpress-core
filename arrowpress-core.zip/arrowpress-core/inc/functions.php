<?php
/**
 * Core functions
 *
 * @package   ArrowPress_Core
 * @since     1.0.0
 */

/**
 * Get instance ArrowPress_Core_Customizer.
 *
 * @return ArrowPress_Core_Customizer
 * @since 0.1.0
 */
if ( ! function_exists( 'arrowpress_customizer' ) ) {
	function arrowpress_customizer() {
		return ArrowPress_Core_Customizer::instance();
	}
}

/**
 * Get page id by path. If not found return false.
 *
 * @param $page_slug
 *
 * @return bool|int
 * @since 0.5.0
 *
 */
if ( ! function_exists( 'arrowpress_get_page_id_by_path' ) ) {
	function arrowpress_get_page_id_by_path( $page_slug ) {
		$page = get_page_by_path( $page_slug );

		if ( $page ) {
			return $page->ID;
		}

		return false;
	}
}

/**
 * Add log.
 *
 * @param        $message
 * @param string $handle
 * @param bool   $clear
 *
 * @since 0.8.3
 *
 */
if ( ! function_exists( 'arrowpress_add_log' ) ) {
	function arrowpress_add_log( $message, $handle = 'log', $clear = false ) {
		if ( ! Apr_Core::is_debug() ) {
			return;
		}

		if ( version_compare( phpversion(), '5.6', '<' ) ) {
			return;
		}

		$arrowpress_log = Arrowpress_Logger::instance();
		@$arrowpress_log->add( $message, $handle, $clear );
	}
}

/**
 * let_to_num function.
 *
 * This function transforms the php.ini notation for numbers (like '2M') to an integer.
 *
 * @param $size
 *
 * @return int
 * @since 1.1.1
 *
 */
function arrowpress_core_let_to_num( $size ) {
	$l   = substr( $size, - 1 );
	$ret = substr( $size, 0, - 1 );
	switch ( strtoupper( $l ) ) {
		case 'P':
			$ret *= 1024;
		case 'T':
			$ret *= 1024;
		case 'G':
			$ret *= 1024;
		case 'M':
			$ret *= 1024;
		case 'K':
			$ret *= 1024;
	}

	return $ret;
}


/**
 * arrowpress_core_breadcrumbs
 *
 * @author  tuanta
 * @since   2.1.2
 * @version 1.0.0
 */
if ( ! function_exists( 'arrowpress_core_breadcrumbs' ) ) {

	/**
	 * Output the Thim Breadcrumb.
	 *
	 */
	function arrowpress_core_breadcrumbs( $args = array() ) {

		$args = wp_parse_args(
			$args,
			apply_filters(
				'arrowpress_breadcrumb_defaults',
				array(
					'delimiter'   => '',
					'wrap_before' => '<ul class="breadcrumbs" id="breadcrumbs">',
					'wrap_after'  => '</ul>',
					'before'      => '<li>',
					'after'       => '</li>',
				)
			)
		);

		$breadcrumbs = new ArrowPressCoreBreadcrumbs\Arrowpress_Breadcrumbs();

		$breadcrumb = $breadcrumbs->render();
		if ( ! empty( $breadcrumb ) ) {
			echo $args['wrap_before'];

			foreach ( $breadcrumb as $key => $crumb ) {
				echo $args['before'];

				if ( ! empty( $crumb[1] ) && sizeof( $breadcrumb ) !== $key + 1 ) {
					echo '<a href="' . esc_url( $crumb[1] ) . '">' . esc_html( $crumb[0] ) . '</a>';
				} else {
					echo esc_html( $crumb[0] );
				}

				echo $args['after'];
				if ( sizeof( $breadcrumb ) !== $key + 1 ) {
					echo $args['delimiter'];
				}
			}

			echo $args['wrap_after'];
		}
	}
}

add_action( 'arrowpress_breadcrumbs', 'arrowpress_core_breadcrumbs', 5 );
if ( ! function_exists( 'arrowpress_breadcrumbs' ) ) {
	function arrowpress_breadcrumbs( $args = array() ) {
		arrowpress_core_breadcrumbs();
	}
}

/* Share social */
if ( ! function_exists( 'arrowpress_core_social_share' ) ) {
	function arrowpress_core_social_share() {
		$sharings = apply_filters(
			'arrowpress_ft_list_social',
			array(
				'facebook',
				'twitter',
				'pinterest',
				'linkedin',
			)
		);

		if ( isset( $sharings ) && $sharings ) {
			echo '<ul class="arrowpress-social-share">';
			do_action( 'before_social_share_list' );

			echo '<li class="heading">' . esc_html__( 'Share:', 'arrowpress-core' ) . '</li>';
			foreach ( $sharings as $sharing ) {
				switch ( $sharing ) {
					case 'facebook':
						echo '<li><div class="facebook-social"><a target="_blank" class="facebook"  href="https://www.facebook.com/sharer.php?u=' . urlencode( get_permalink() ) . '" title="' . esc_attr__( 'Facebook', 'arrowpress-core' ) . '"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M80 299.3V512H196V299.3h86.5l18-97.8H196V166.9c0-51.7 20.3-71.5 72.7-71.5c16.3 0 29.4 .4 37 1.2V7.9C291.4 4 256.4 0 236.2 0C129.3 0 80 50.5 80 159.4v42.1H14v97.8H80z"/></svg></a></div></li>';
						break;
					case 'twitter':
						echo '<li><div class="twitter-social"><a target="_blank" class="twitter" href="https://twitter.com/share?url=' . urlencode( get_permalink() ) . '&amp;text=' . rawurlencode( esc_attr( get_the_title() ) ) . '" title="' . esc_attr__( 'Twitter', 'arrowpress-core' ) . '"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"/></svg></a></div></li>';
						break;
					case 'pinterest':
						echo '<li><div class="pinterest-social"><a target="_blank" class="pinterest"  href="http://pinterest.com/pin/create/button/?url=' . urlencode( get_permalink() ) . '&amp;description=' . rawurlencode( esc_attr( get_the_excerpt() ) ) . '&amp;media=' . urlencode( wp_get_attachment_url( get_post_thumbnail_id() ) ) . '" onclick="window.open(this.href); return false;" title="' . esc_attr__( 'Pinterest', 'arrowpress-core' ) . '"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M204 6.5C101.4 6.5 0 74.9 0 185.6 0 256 39.6 296 63.6 296c9.9 0 15.6-27.6 15.6-35.4 0-9.3-23.7-29.1-23.7-67.8 0-80.4 61.2-137.4 140.4-137.4 68.1 0 118.5 38.7 118.5 109.8 0 53.1-21.3 152.7-90.3 152.7-24.9 0-46.2-18-46.2-43.8 0-37.8 26.4-74.4 26.4-113.4 0-66.2-93.9-54.2-93.9 25.8 0 16.8 2.1 35.4 9.6 50.7-13.8 59.4-42 147.9-42 209.1 0 18.9 2.7 37.5 4.5 56.4 3.4 3.8 1.7 3.4 6.9 1.5 50.4-69 48.6-82.5 71.4-172.8 12.3 23.4 44.1 36 69.3 36 106.2 0 153.9-103.5 153.9-196.8C384 71.3 298.2 6.5 204 6.5z"/></svg></a></div></li>';
						break;
					case 'linkedin':
						echo '<li><div class="linkedin-social"><a target="_blank" class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=' . urlencode( get_permalink() ) . '&title=' . rawurlencode( get_the_title() ) . '&summary=' . rawurlencode( get_the_excerpt() ) . '" title="' . esc_attr__( 'LinkedIn', 'arrowpress-core' ) . '"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M100.28 448H7.4V148.9h92.88zm-46.14-340.8C24.2 107.2 0 82.4 0 53.6 0 24.8 24.2 0 54.14 0c29.94 0 54.14 24.8 54.14 53.6 0 28.8-24.2 53.6-54.14 53.6zM447.9 448h-92.68V302.4c0-34.7-12.4-58.4-43.4-58.4-23.7 0-37.8 15.9-44 31.2-2.3 5.6-2.8 13.4-2.8 21.2V448h-92.68s1.2-239.4 0-264.1h92.68v37.4c12.3-19 34.3-46.1 83.4-46.1 60.8 0 106.4 39.7 106.4 125.1V448z"/></svg></a></div></li>';
						break;
				}
			}

			do_action( 'after_social_share_list' );

			echo '</ul>';
		}
	}
}
add_action( 'arrowpress_social_share', 'arrowpress_core_social_share' );

// add type upload_mimes: svg
if ( ! function_exists( 'arrowpress_add_type_upload_mime' ) ) { 
	function arrowpress_add_type_upload_mime($mimes) { 
		$mimes['svg'] = 'image/svg+xml'; 
		return $mimes; 
	} 

	add_filter('upload_mimes', 'arrowpress_add_type_upload_mime' );
}