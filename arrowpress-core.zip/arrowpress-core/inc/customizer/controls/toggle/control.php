<?php
namespace ArrowTheme\Customizer\Control;

defined( 'ABSPATH' ) || exit;

class Toggle extends Checkbox_Switch {

	public $type = 'arrowpress-toggle';
}
