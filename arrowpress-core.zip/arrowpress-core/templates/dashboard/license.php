<?php
$token         = Arrowpress_Product_Registration::get_data_theme_register( 'purchase_token' );
$purchase_code = Arrowpress_Product_Registration::get_data_theme_register( 'purchase_code' );
$user          = wp_get_current_user();

$theme_data = Arrowpress_Theme_Manager::get_metadata();
$theme      = $theme_data['text_domain'];
$version    = $theme_data['version']; 
?>

<div class="tc-box tc-box-theme-license">
	<div class="tc-box-header">
		<h2 class="box-title">Activate your theme license</h2>
	</div>

	<div class="tc-box-body">
		<?php if ($token) : ?>
			<div class="wrapper-message">
				<div class="message-success message">Your theme license is activated. Thank you!</div>
			</div>
			<table class="form-table">
				<tbody>
					<?php if (! empty($purchase_code)) : ?>
						<tr class="license-active">
							<th scope="row">
								<?php esc_html_e('Purchase code: ', 'arrowpress-core'); ?>
							</th>
							<td>
								<?php // Show purchase code with **** and last 3 characters of the purchase code with format uuid4
								?>
								<input type="text"
									value="<?php echo esc_html(str_repeat('*', strlen($purchase_code) - 7) . substr($purchase_code, -4)); ?>"
									disabled>
								<button
									class="arrow-deactivate button button-secondary tc-button deactivate-btn tc-run-step">
									<?php esc_html_e('Deactivate', 'arrowpress-core'); ?>
								</button>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		<?php else: ?>
			<div class="wrapper-message">
				<div class="message-info message">Activate your purchase code for this domain to turn on install plugin required and import data demo</div>
			</div>
				<form class="arrowpress-form-license" action="" method="post">
					<table class="form-table">
						<tbody>
							<tr>
								<th scope="row">Purchase code <span class="required">*</span></th>
								<td>
									<input type="text" id="purchase_code" name="purchase_code" value=""
										placeholder="Enter purchase code" autocomplete="off" required>
									<p class="find-license">
										<a href="https://thimpress.com/my-account/"
											target="_blank" rel="noopener">Get my purchase code from ThimPress
										</a>
											<a href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code"
												target="_blank" rel="noopener">Get my purchase code from Envato Market
											</a>
										</p>
								</td>
							</tr>
						</tbody>
					</table>
					<p>
						<label for="agree_stored" class="agree-label">
							<input type="checkbox" name="agree_stored" id="agree_stored" required>
							I agree that my purchase code and user data will be stored by arrowtheme.com
						</label>
					</p>

					<input type="hidden" name="domain" value="<?php echo esc_url(site_url()); ?>">
					<input type="hidden" name="theme" value="<?php echo esc_attr($theme); ?>">
					<input type="hidden" name="theme_version" value="<?php echo esc_attr($version); ?>">
					<input type="hidden" name="user_email"
						value="<?php echo esc_attr($user ? $user->user_email : ''); ?>">

					<button class="button button-primary tc-button activate-btn tc-run-step" type="submit">
						<?php esc_html_e('Submit', 'arrowpress-core'); ?>
					</button>
				</form>
			<?php endif; ?>

			</div>
			<div class="tc-box-footer">
				<p>Note: you are allowed to use our theme only on one domain if you purchased a regular license.</p>
			</div>
	</div>
</div>
