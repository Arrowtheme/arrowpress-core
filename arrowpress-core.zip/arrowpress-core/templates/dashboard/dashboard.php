<div class="tc-dashboard-wrapper wrap">
    <?php
        do_action('arrowpress_dashboard_registration_box');
        do_action('arrowpress_dashboard_boxes_content');
    ?>
</div>