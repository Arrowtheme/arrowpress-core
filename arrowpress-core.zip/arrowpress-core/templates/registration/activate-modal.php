<h3 class="title">Product registration<span class="close"></span></h3>

<div class="main">
    <div class="text-center">
        <p>This feature is only available to registered users. Just try to login with your Envato account here.</p>

		<?php Arrowpress_Template_Helper::template( 'dashboard/partials/button-activate.php', array(), true ); ?>
    </div>
</div>
