<?php

/**
 * Class Arrowpress_Admin_Config
 *
 * @since 1.1.0
 */
class Arrowpress_Admin_Config extends Arrowpress_Singleton {
	/**
	 * @since 1.1.0
	 *
	 * @var null
	 */
	private static $configs = null;

	/**
	 * Arrowpress_Admin_Config constructor.
	 */
	protected function __construct() {
		$this->set_config();
	}

	/**
	 * Set configs.
	 *
	 * @since 1.1.0
	 */
	private function set_config() {
		self::$configs = array(
			'api_check_self_update' => 'https://arrowtheme.github.io/arrowpress-core/update-check.json',
			'api_update_plugins'    => 'https://updates.thimpress.com/wp-json/thim_em/v1/plugins',
			'api_plugins_extend'    => 'https://downloads.thimpress.com/',
			'api_arrow_market'      => 'https://updates.thimpress.com/wp-json/thim-market/v1',
			'host_envato_app'       => 'https://updates.thimpress.com/thim-envato-market',
			'host_downloads'        => 'https://updates.thimpress.com/thim-envato-market',
			'demo_data'             => 'https://arrowtheme.github.io/demo-data/',
			'host_downloads_api'    => 'https://updates.thimpress.com/',
		);
	}

	/**
	 * Get config by key.
	 *
	 * @param      $key
	 * @param null $default
	 *
	 * @return mixed|null
	 * @since 1.1.0
	 *
	 */
	public static function get( $key, $default = null ) {
		if ( ! isset( self::$configs[ $key ] ) ) {
			return $default;
		}

		return apply_filters( "arrowpress_core_ac_$key", self::$configs[ $key ] );
	}
}
