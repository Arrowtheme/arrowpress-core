=== ArrowPress Core ===
Contributors: Arrowtheme, tuanta
Donate link: https://arrowtheme.com
Tags: admin, customize, framework
Requires at least: 4.8
Tested up to: 5.8
Stable tag: 2.0.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The Ultimate Core Processor of all WordPress themes by ArrowTheme - Manage your website easier with ArrowPress Core.

== Description ==

ArrowPress Core is a Core Processor of all **WordPress themes by ArrowTheme** and it is meant to be used only with ArrowTheme's WordPress themes.

# What themes does ArrowPress Core support
 View [ArrowTheme site](https://arrowtheme.com) or [ArrowTheme's Portfolio](https://themeforest
 .net/user/ArrowTheme/portfolio?ref=ArrowTheme)
# What does ArrowPress Core do:
- Register necessary custom post types, custom fields for the themes
- Add a Control Panel, Customization Page to easier manage the theme
- Works as a One-Click Installer to install WordPress themes easier

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/arrowpress-core` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Read our guide on how to Get Started with ArrowPress Core.


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 2.0.0 =
~ Rewrite import Demo
